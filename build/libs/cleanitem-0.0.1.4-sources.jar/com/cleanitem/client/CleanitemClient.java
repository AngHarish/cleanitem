package com.cleanitem.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class CleanitemClient implements ClientModInitializer {

    // 声明三个按键绑定变量
    public static class_304 clearItemKey;
    public static class_304 timeDayKey;
    public static class_304 weatherClearKey;

    @Override
    public void onInitializeClient() {
        // 1. 注册 Delete 键 (清除掉落物)
        clearItemKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.cleanitem.clear_items", 
                class_3675.class_307.field_1668,       
                GLFW.GLFW_KEY_DELETE,        
                "category.cleanitem.keys"    
        ));

        // 2. 注册 \ 键 (设置白天)
        timeDayKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.cleanitem.time_day",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_BACKSLASH, // \ 键的 GLFW 代码
                "category.cleanitem.keys"
        ));

        // 3. 注册 - 键 (清除天气)
        weatherClearKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.cleanitem.weather_clear",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_MINUS, // - 键的 GLFW 代码
                "category.cleanitem.keys"
        ));

        // 注册客户端 Tick 事件，统一处理按键逻辑
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // 确保玩家和世界已经加载
            if (client.field_1724 != null && client.field_1687 != null) {
                
                // 处理 Delete 键
                while (clearItemKey.method_1436()) {
                    client.field_1724.field_3944.method_45730("kill @e[type=item]");
                }

                // 处理 \ 键
                while (timeDayKey.method_1436()) {
                    client.field_1724.field_3944.method_45730("time set day");
                }

                // 处理 - 键
                while (weatherClearKey.method_1436()) {
                    client.field_1724.field_3944.method_45730("weather clear");
                }
            }
        });
    }
}